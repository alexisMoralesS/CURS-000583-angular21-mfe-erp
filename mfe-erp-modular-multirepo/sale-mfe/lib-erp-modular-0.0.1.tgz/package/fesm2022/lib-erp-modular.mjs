import * as i0 from '@angular/core';
import { Component, input, contentChild, inject, signal, Injectable, ElementRef, effect, HostListener, Directive } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { NgTemplateOutlet } from '@angular/common';
import { Router } from '@angular/router';
import { firstValueFrom } from 'rxjs';

class LibErpModular {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.18", ngImport: i0, type: LibErpModular, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.18", type: LibErpModular, isStandalone: true, selector: "lib-libErpModular", ngImport: i0, template: ` <p>lib-erp-modular works!</p> `, isInline: true, styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.18", ngImport: i0, type: LibErpModular, decorators: [{
            type: Component,
            args: [{ selector: 'lib-libErpModular', imports: [], template: ` <p>lib-erp-modular works!</p> ` }]
        }] });

class FormControlError {
    control = input.required(...(ngDevMode ? [{ debugName: "control" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.18", ngImport: i0, type: FormControlError, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.18", type: FormControlError, isStandalone: true, selector: "app-form-control-error", inputs: { control: { classPropertyName: "control", publicName: "control", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: "@if (control()?.invalid && (control()?.dirty || control()?.touched)) {\n  <span class=\"text-sm text-red-500\">\n    @let errors = control()?.errors ?? {};\n    @if (errors?.['required']) {\n      Este campo es requerido.\n    } @else if (errors['email']) {\n      Ingrese un correo electr\u00F3nico v\u00E1lido.\n    } @else if (errors['minlength']) {\n      M\u00EDnimo {{ errors['minlength'].requiredLength }} caracteres.\n    } @else if (errors['passwordsMismatch']) {\n      Las contrase\u00F1as no coinciden.\n    }\n  </span>\n}\n", styles: [""], dependencies: [{ kind: "ngmodule", type: ReactiveFormsModule }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.18", ngImport: i0, type: FormControlError, decorators: [{
            type: Component,
            args: [{ selector: 'app-form-control-error', imports: [ReactiveFormsModule], template: "@if (control()?.invalid && (control()?.dirty || control()?.touched)) {\n  <span class=\"text-sm text-red-500\">\n    @let errors = control()?.errors ?? {};\n    @if (errors?.['required']) {\n      Este campo es requerido.\n    } @else if (errors['email']) {\n      Ingrese un correo electr\u00F3nico v\u00E1lido.\n    } @else if (errors['minlength']) {\n      M\u00EDnimo {{ errors['minlength'].requiredLength }} caracteres.\n    } @else if (errors['passwordsMismatch']) {\n      Las contrase\u00F1as no coinciden.\n    }\n  </span>\n}\n" }]
        }], propDecorators: { control: [{ type: i0.Input, args: [{ isSignal: true, alias: "control", required: true }] }] } });

class PageLayoutComponent {
    title = contentChild('title', ...(ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []));
    actions = contentChild('actions', ...(ngDevMode ? [{ debugName: "actions" }] : /* istanbul ignore next */ []));
    content = contentChild('content', ...(ngDevMode ? [{ debugName: "content" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.18", ngImport: i0, type: PageLayoutComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.18", type: PageLayoutComponent, isStandalone: true, selector: "lib-page-layout", queries: [{ propertyName: "title", first: true, predicate: ["title"], descendants: true, isSignal: true }, { propertyName: "actions", first: true, predicate: ["actions"], descendants: true, isSignal: true }, { propertyName: "content", first: true, predicate: ["content"], descendants: true, isSignal: true }], ngImport: i0, template: "<div class=\"flex flex-col p-4\">\n  <div class=\"grid grid-cols-1 md:grid-cols-2 mb-4\">\n    <div class=\"text-2xl\">\n      @if (title(); as tpl) {\n        <ng-container *ngTemplateOutlet=\"tpl\" />\n      }\n    </div>\n\n    <div class=\"flex justify-end\">\n      @if (actions(); as tpl) {\n        <ng-container *ngTemplateOutlet=\"tpl\" />\n      }\n    </div>\n  </div>\n\n  <div class=\"w-full\">\n    @if (content(); as tpl) {\n      <ng-container *ngTemplateOutlet=\"tpl\" />\n    }\n  </div>\n</div>\n", styles: [""], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.18", ngImport: i0, type: PageLayoutComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-page-layout', imports: [NgTemplateOutlet], template: "<div class=\"flex flex-col p-4\">\n  <div class=\"grid grid-cols-1 md:grid-cols-2 mb-4\">\n    <div class=\"text-2xl\">\n      @if (title(); as tpl) {\n        <ng-container *ngTemplateOutlet=\"tpl\" />\n      }\n    </div>\n\n    <div class=\"flex justify-end\">\n      @if (actions(); as tpl) {\n        <ng-container *ngTemplateOutlet=\"tpl\" />\n      }\n    </div>\n  </div>\n\n  <div class=\"w-full\">\n    @if (content(); as tpl) {\n      <ng-container *ngTemplateOutlet=\"tpl\" />\n    }\n  </div>\n</div>\n" }]
        }], propDecorators: { title: [{ type: i0.ContentChild, args: ['title', { isSignal: true }] }], actions: [{ type: i0.ContentChild, args: ['actions', { isSignal: true }] }], content: [{ type: i0.ContentChild, args: ['content', { isSignal: true }] }] } });

const MFE_EVENTS = {
    ROUTE_CHANGED: 'routeChanged',
};
const MFE_CUSTOMER_EVENTS = {
    CUSTOMER_SELECTED: 'customer.selected',
};
const MFE_PRODUCT_EVENTS = {
    PRODUCT_SELECTED: 'product.selected',
};

class MFENavigateService {
    router = inject(Router);
    _navigation = signal(false, ...(ngDevMode ? [{ debugName: "_navigation" }] : /* istanbul ignore next */ []));
    navigation = this._navigation.asReadonly();
    _currentRoute = signal('', ...(ngDevMode ? [{ debugName: "_currentRoute" }] : /* istanbul ignore next */ []));
    currentRoute = this._currentRoute.asReadonly();
    navigate(mfeBase, route, extras) {
        let url;
        if (this.isHost()) {
            url = this.buildUrl(mfeBase, route);
            this.notifyHostNavigation(url, extras);
        }
        else {
            url = this.buildUrl('', route);
            this.router.navigate([url], extras);
        }
        this._currentRoute.set(url);
        this._navigation.set(true);
    }
    isHost() {
        return Boolean(window.isHost);
    }
    notifyHostNavigation(route, extras) {
        window.dispatchEvent(new CustomEvent(MFE_EVENTS.ROUTE_CHANGED, {
            detail: {
                route,
                extras,
            },
        }));
    }
    buildUrl(mfeBase, route) {
        if (this.isHost()) {
            return `${this.clean(mfeBase)}/${this.clean(route)}`;
        }
        return `${this.clean(route)}`;
    }
    clean(path) {
        return path.replace(/^\/+|\/+$/g, '');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.18", ngImport: i0, type: MFENavigateService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.18", ngImport: i0, type: MFENavigateService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.18", ngImport: i0, type: MFENavigateService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

class MFERouterLinkDirective {
    mfeRouterLink = input('', ...(ngDevMode ? [{ debugName: "mfeRouterLink" }] : /* istanbul ignore next */ []));
    routerLinkActive = input('active', ...(ngDevMode ? [{ debugName: "routerLinkActive" }] : /* istanbul ignore next */ []));
    queryParams = input(...(ngDevMode ? [undefined, { debugName: "queryParams" }] : /* istanbul ignore next */ []));
    mfeBase = input('', ...(ngDevMode ? [{ debugName: "mfeBase" }] : /* istanbul ignore next */ []));
    navigateService = inject(MFENavigateService);
    elementRef = inject(ElementRef);
    constructor() {
        effect(() => {
            const currentRoute = this.navigateService.currentRoute();
            const targetRoute = `${this.mfeBase()}/${this.mfeRouterLink()}`;
            const activeClass = this.routerLinkActive();
            if (currentRoute === targetRoute) {
                this.elementRef.nativeElement.classList.add(activeClass);
            }
            else {
                this.elementRef.nativeElement.classList.remove(activeClass);
            }
        });
    }
    navigate() {
        this.navigateService.navigate(this.mfeBase(), this.mfeRouterLink(), {
            queryParams: this.queryParams(),
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.18", ngImport: i0, type: MFERouterLinkDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.18", type: MFERouterLinkDirective, isStandalone: true, selector: "[mfeRouterLink]", inputs: { mfeRouterLink: { classPropertyName: "mfeRouterLink", publicName: "mfeRouterLink", isSignal: true, isRequired: false, transformFunction: null }, routerLinkActive: { classPropertyName: "routerLinkActive", publicName: "routerLinkActive", isSignal: true, isRequired: false, transformFunction: null }, queryParams: { classPropertyName: "queryParams", publicName: "queryParams", isSignal: true, isRequired: false, transformFunction: null }, mfeBase: { classPropertyName: "mfeBase", publicName: "mfeBase", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "click": "navigate()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.18", ngImport: i0, type: MFERouterLinkDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[mfeRouterLink]',
                }]
        }], ctorParameters: () => [], propDecorators: { mfeRouterLink: [{ type: i0.Input, args: [{ isSignal: true, alias: "mfeRouterLink", required: false }] }], routerLinkActive: [{ type: i0.Input, args: [{ isSignal: true, alias: "routerLinkActive", required: false }] }], queryParams: [{ type: i0.Input, args: [{ isSignal: true, alias: "queryParams", required: false }] }], mfeBase: [{ type: i0.Input, args: [{ isSignal: true, alias: "mfeBase", required: false }] }], navigate: [{
                type: HostListener,
                args: ['click']
            }] } });

class EventBusService {
    emit(event, detail) {
        window.dispatchEvent(new CustomEvent(event, {
            detail,
        }));
    }
    on(event, listener) {
        const handler = (e) => {
            listener(e.detail);
        };
        window.addEventListener(event, handler);
        return () => window.removeEventListener(event, handler);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.18", ngImport: i0, type: EventBusService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.18", ngImport: i0, type: EventBusService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.18", ngImport: i0, type: EventBusService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

class AppConfigService {
    config = signal(null, ...(ngDevMode ? [{ debugName: "config" }] : /* istanbul ignore next */ []));
    setConfig(config) {
        this.config.set(config);
    }
    get value() {
        const config = this.config();
        if (!config) {
            throw new Error('Config no cargada');
        }
        return config;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.18", ngImport: i0, type: AppConfigService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.18", ngImport: i0, type: AppConfigService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.18", ngImport: i0, type: AppConfigService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

async function loadConfig(http, configService, path) {
    const config = await firstValueFrom(http.get(path));
    configService.setConfig(config);
}

/*
 * Public API Surface of lib-erp-modular
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AppConfigService, EventBusService, FormControlError, LibErpModular, MFENavigateService, MFERouterLinkDirective, MFE_CUSTOMER_EVENTS, MFE_EVENTS, MFE_PRODUCT_EVENTS, PageLayoutComponent, loadConfig };
//# sourceMappingURL=lib-erp-modular.mjs.map
