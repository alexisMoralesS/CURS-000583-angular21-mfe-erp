import * as i0 from '@angular/core';
import { TemplateRef } from '@angular/core';
import { AbstractControl } from '@angular/forms';
import { NavigationExtras } from '@angular/router';
import { HttpClient } from '@angular/common/http';

declare class LibErpModular {
    static ɵfac: i0.ɵɵFactoryDeclaration<LibErpModular, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LibErpModular, "lib-libErpModular", never, {}, {}, never, never, true, never>;
}

declare class FormControlError {
    control: i0.InputSignal<AbstractControl<any, any, any> | null>;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormControlError, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormControlError, "app-form-control-error", never, { "control": { "alias": "control"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class PageLayoutComponent {
    readonly title: i0.Signal<TemplateRef<unknown> | undefined>;
    readonly actions: i0.Signal<TemplateRef<unknown> | undefined>;
    readonly content: i0.Signal<TemplateRef<unknown> | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PageLayoutComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PageLayoutComponent, "lib-page-layout", never, {}, {}, ["title", "actions", "content"], never, true, never>;
}

declare class MFERouterLinkDirective {
    readonly mfeRouterLink: i0.InputSignal<string>;
    readonly routerLinkActive: i0.InputSignal<string>;
    readonly queryParams: i0.InputSignal<any>;
    readonly mfeBase: i0.InputSignal<string>;
    private readonly navigateService;
    private readonly elementRef;
    constructor();
    navigate(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MFERouterLinkDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MFERouterLinkDirective, "[mfeRouterLink]", never, { "mfeRouterLink": { "alias": "mfeRouterLink"; "required": false; "isSignal": true; }; "routerLinkActive": { "alias": "routerLinkActive"; "required": false; "isSignal": true; }; "queryParams": { "alias": "queryParams"; "required": false; "isSignal": true; }; "mfeBase": { "alias": "mfeBase"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class EventBusService {
    emit<T>(event: string, detail: T): void;
    on<T>(event: string, listener: (detail: T) => void): () => void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EventBusService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EventBusService>;
}

declare class MFENavigateService {
    private readonly router;
    private readonly _navigation;
    readonly navigation: i0.Signal<boolean>;
    private readonly _currentRoute;
    readonly currentRoute: i0.Signal<string>;
    navigate(mfeBase: string, route: string, extras?: NavigationExtras): void;
    private isHost;
    private notifyHostNavigation;
    private buildUrl;
    private clean;
    static ɵfac: i0.ɵɵFactoryDeclaration<MFENavigateService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MFENavigateService>;
}

declare const MFE_EVENTS: {
    readonly ROUTE_CHANGED: "routeChanged";
};
declare const MFE_CUSTOMER_EVENTS: {
    readonly CUSTOMER_SELECTED: "customer.selected";
};
declare const MFE_PRODUCT_EVENTS: {
    readonly PRODUCT_SELECTED: "product.selected";
};

interface AppConfig {
    apiUrl: string;
    production: boolean;
}

declare class AppConfigService {
    readonly config: i0.WritableSignal<AppConfig | null>;
    setConfig(config: AppConfig): void;
    get value(): AppConfig;
    static ɵfac: i0.ɵɵFactoryDeclaration<AppConfigService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AppConfigService>;
}

declare function loadConfig(http: HttpClient, configService: AppConfigService, path: string): Promise<void>;

interface CustomerSelectedDto {
    id: string;
    name: string;
    documentType: string;
    numberDocument: string;
    phone: string;
    email: string;
}

interface ProductSelectedDto {
    id: string;
    name: string;
    price: number;
}

export { AppConfigService, EventBusService, FormControlError, LibErpModular, MFENavigateService, MFERouterLinkDirective, MFE_CUSTOMER_EVENTS, MFE_EVENTS, MFE_PRODUCT_EVENTS, PageLayoutComponent, loadConfig };
export type { AppConfig, CustomerSelectedDto, ProductSelectedDto };
